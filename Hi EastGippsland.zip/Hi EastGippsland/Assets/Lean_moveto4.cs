﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lean_moveto4 : MonoBehaviour
{

    public GameObject go_object; 
    public float moveSpeed = 0.18f; 

    bool isTouching = false; 

    // Update is called once per frame 
    void Update() 
    { 
        if (Input.touchCount > 1) 
            return; 
        if (Input.touchCount == 1) 
        { 
            if (Input.touches[0].phase == TouchPhase.Began) 
            { 
                Ray ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position); 
                RaycastHit hit = new RaycastHit(); 
                if (Physics.Raycast(ray, out hit)) 
                { 
                    if (hit.collider.gameObject.name == go_object.name) 
                        isTouching = true; 
                } 
            } 
            //Move object 
            if (isTouching && (Input.touches[0].phase == TouchPhase.Moved || Input.touches[0].phase == TouchPhase.Stationary)) 
            { 
                Vector2 touchDeltaPosition = Input.touches[0].deltaPosition; 
                go_object.transform.Translate(touchDeltaPosition.x * moveSpeed * Time.deltaTime, touchDeltaPosition.y * moveSpeed * Time.deltaTime, 0); 
            } 
            if (isTouching && Input.touches[0].phase == TouchPhase.Ended) 
                isTouching = false; 
        } 
    } 
}
