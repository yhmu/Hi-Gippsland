﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lean_move5 : MonoBehaviour
{

    private Touch oldTouch1;  //last touch point1(finger1)
    private Touch oldTouch2;  //last touch point2(finger2)
    void Update()
    {
        //No touch, touch point is 0
        if (Input.touchCount <= 0)
        {
            return;
        }
        //Single touch, horizontal movement
        if (1 == Input.touchCount)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Moved)
            {
                Vector3 dir = new Vector3(touch.deltaPosition.x, touch.deltaPosition.y, 0f) * 0.01f; transform.Translate(dir);
            }
        }
        //Multi-touch, zoom in and out
        Touch newTouch1 = Input.GetTouch(0);
        Touch newTouch2 = Input.GetTouch(1);
        //Point 2 just started to touch the screen, only record, do not process
        if (newTouch2.phase == TouchPhase.Began)
        {
            oldTouch2 = newTouch2;
            oldTouch1 = newTouch1;
            return;
        }
        //Calculate the old two-point distance and the new distance between the two points. If you want to enlarge the model, you need to zoom in and zoom out.
        float oldDistance = Vector2.Distance(oldTouch1.position, oldTouch2.position);
        float newDistance = Vector2.Distance(newTouch1.position, newTouch2.position);
        //The difference between the two distances is positive for the zoom-in gesture and negative for the zoom-out gesture
        float offset = newDistance - oldDistance;
        //Magnification factor, one pixel is calculated as 0.01 times (100 adjustable)
        float scaleFactor = offset / 100f;
        Vector3 localScale = transform.localScale;
        Vector3 scale = new Vector3(localScale.x + scaleFactor,
                                    localScale.y + scaleFactor,
                                    localScale.z + scaleFactor);
        //Under what circumstances to zoom
        if (scale.x >= 0.05f && scale.y >= 0.05f && scale.z >= 0.05f)
        {
            transform.localScale = scale;
        }
        //Remember the latest touch points, next time you use
        oldTouch1 = newTouch1;
        oldTouch2 = newTouch2;
    }


}
